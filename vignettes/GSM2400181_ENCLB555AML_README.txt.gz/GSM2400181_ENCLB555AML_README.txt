
***************
file name: ENCFF459OFD.bam
file encode accession: ENCFF459OFD
status: released
file format: bam
file type: bam
href: https://www.encodeproject.org/files/ENCFF459OFD/@@download/ENCFF459OFD.bam
output category: alignment
output type: alignments
assembly: GRCh38
biological replicate number: 3
technical replicate number: 1
biological replicates: 3
technical replicates: 3_1

***************
file name: ENCFF453VFT.bam
file encode accession: ENCFF453VFT
status: released
file format: bam
file type: bam
href: https://www.encodeproject.org/files/ENCFF453VFT/@@download/ENCFF453VFT.bam
output category: alignment
output type: transcriptome alignments
assembly: GRCh38
biological replicate number: 3
technical replicate number: 1
biological replicates: 3
technical replicates: 3_1

***************
file name: ENCFF087TEB_minus_strand_signal_of_unique_reads_GRCh38.bigWig
file encode accession: ENCFF087TEB
status: released
file format: bigWig
file type: bigWig
file size: 397107808
md5sum: 0fe761dd537eb3bad815b213c31d60fe
output category: signal
output type: minus strand signal of unique reads
assembly: GRCh38
genome annotation: V24
biological replicate number: 3
technical replicate number: 1
biological replicates: 3
technical replicates: 3_1
derived from: ENCFF459OFD.bam

***************
file name: ENCFF397EHE_plus_strand_signal_of_unique_reads_GRCh38.bigWig
file encode accession: ENCFF397EHE
status: released
file format: bigWig
file type: bigWig
file size: 409477098
md5sum: 00f0cd2f4d415913c031034465fa8080
output category: signal
output type: plus strand signal of unique reads
assembly: GRCh38
genome annotation: V24
biological replicate number: 3
technical replicate number: 1
biological replicates: 3
technical replicates: 3_1
derived from: ENCFF459OFD.bam

***************
file name: ENCFF411CUQ_plus_strand_signal_of_all_reads_GRCh38.bigWig
file encode accession: ENCFF411CUQ
status: released
file format: bigWig
file type: bigWig
file size: 455195495
md5sum: 0220a02b17ec5a374142cecf7bcee411
output category: signal
output type: plus strand signal of all reads
assembly: GRCh38
genome annotation: V24
biological replicate number: 3
technical replicate number: 1
biological replicates: 3
technical replicates: 3_1
derived from: ENCFF459OFD.bam

***************
file name: ENCFF251NZV_minus_strand_signal_of_all_reads_GRCh38.bigWig
file encode accession: ENCFF251NZV
status: released
file format: bigWig
file type: bigWig
file size: 445857185
md5sum: c60180efdd1384799d84515821486fc4
output category: signal
output type: minus strand signal of all reads
assembly: GRCh38
genome annotation: V24
biological replicate number: 3
technical replicate number: 1
biological replicates: 3
technical replicates: 3_1
derived from: ENCFF459OFD.bam

***************
file name: ENCFF428OKC_gene_quantifications_GRCh38.tsv
file encode accession: ENCFF428OKC
status: released
file format: tsv
file type: tsv
file size: 9855454
md5sum: 09df22bdf33838d2117a2bd123247d58
output category: quantification
output type: gene quantifications
assembly: GRCh38
genome annotation: V24
biological replicate number: 3
technical replicate number: 1
biological replicates: 3
technical replicates: 3_1
derived from: ENCFF940AZB; ENCFF453VFT.bam

***************
file name: ENCFF922HVB_transcript_quantifications_GRCh38.tsv
file encode accession: ENCFF922HVB
status: released
file format: tsv
file type: tsv
file size: 26530160
md5sum: 0b82aa3171822dec6ca4e57aa8a81dd4
output category: quantification
output type: transcript quantifications
assembly: GRCh38
genome annotation: V24
biological replicate number: 3
technical replicate number: 1
biological replicates: 3
technical replicates: 3_1
derived from: ENCFF940AZB; ENCFF453VFT.bam

***************
file name: ENCFF942EZM.bam
file encode accession: ENCFF942EZM
status: released
file format: bam
file type: bam
href: https://www.encodeproject.org/files/ENCFF942EZM/@@download/ENCFF942EZM.bam
output category: alignment
output type: alignments
assembly: hg19
biological replicate number: 3
technical replicate number: 1
biological replicates: 3
technical replicates: 3_1

***************
file name: ENCFF551HNA.bam
file encode accession: ENCFF551HNA
status: released
file format: bam
file type: bam
href: https://www.encodeproject.org/files/ENCFF551HNA/@@download/ENCFF551HNA.bam
output category: alignment
output type: transcriptome alignments
assembly: hg19
biological replicate number: 3
technical replicate number: 1
biological replicates: 3
technical replicates: 3_1

***************
file name: ENCFF505LIU_plus_strand_signal_of_unique_reads_hg19.bigWig
file encode accession: ENCFF505LIU
status: released
file format: bigWig
file type: bigWig
file size: 409176853
md5sum: 0811c8de1a224e50a9971ce65c687346
output category: signal
output type: plus strand signal of unique reads
assembly: hg19
genome annotation: V19
biological replicate number: 3
technical replicate number: 1
biological replicates: 3
technical replicates: 3_1
derived from: ENCFF942EZM.bam

***************
file name: ENCFF273WNI_transcript_quantifications_hg19.tsv
file encode accession: ENCFF273WNI
status: released
file format: tsv
file type: tsv
file size: 26085254
md5sum: 532aa1765353cde4d4dc558e783e08aa
output category: quantification
output type: transcript quantifications
assembly: hg19
genome annotation: V19
biological replicate number: 3
technical replicate number: 1
biological replicates: 3
technical replicates: 3_1
derived from: ENCFF826ONU; ENCFF551HNA.bam

***************
file name: ENCFF136LHK_minus_strand_signal_of_unique_reads_hg19.bigWig
file encode accession: ENCFF136LHK
status: released
file format: bigWig
file type: bigWig
file size: 397023113
md5sum: 99e8e4c2cc950c5c34ffcebfa013ea45
output category: signal
output type: minus strand signal of unique reads
assembly: hg19
genome annotation: V19
biological replicate number: 3
technical replicate number: 1
biological replicates: 3
technical replicates: 3_1
derived from: ENCFF942EZM.bam

***************
file name: ENCFF803XWW_plus_strand_signal_of_all_reads_hg19.bigWig
file encode accession: ENCFF803XWW
status: released
file format: bigWig
file type: bigWig
file size: 449193673
md5sum: 190f6eeee6ad4b517267b10dbc4efb7e
output category: signal
output type: plus strand signal of all reads
assembly: hg19
genome annotation: V19
biological replicate number: 3
technical replicate number: 1
biological replicates: 3
technical replicates: 3_1
derived from: ENCFF942EZM.bam

***************
file name: ENCFF792WMS_gene_quantifications_hg19.tsv
file encode accession: ENCFF792WMS
status: released
file format: tsv
file type: tsv
file size: 9486722
md5sum: a84ae28b75b5a1d388edd56b7020e8c8
output category: quantification
output type: gene quantifications
assembly: hg19
genome annotation: V19
biological replicate number: 3
technical replicate number: 1
biological replicates: 3
technical replicates: 3_1
derived from: ENCFF826ONU; ENCFF551HNA.bam

***************
file name: ENCFF563LIU_minus_strand_signal_of_all_reads_hg19.bigWig
file encode accession: ENCFF563LIU
status: released
file format: bigWig
file type: bigWig
file size: 441347928
md5sum: 1f891d55380b700ed88b176926cf3f76
output category: signal
output type: minus strand signal of all reads
assembly: hg19
genome annotation: V19
biological replicate number: 3
technical replicate number: 1
biological replicates: 3
technical replicates: 3_1
derived from: ENCFF942EZM.bam

***************
file name: ENCFF000HMC_transcript_quantifications_hg19.gtf.gz (series supplementary file)
file encode accession: ENCFF000HMC
status: archived
file format: gtf
file type: gtf
file size: 4902018
md5sum: 52a6195376219204e07407fd9041e16f
content md5sum: f46db5384d62873546683746275e825c
output category: quantification
output type: transcript quantifications
assembly: hg19
biological replicates: 
technical replicates: 

***************
file name: ENCFF000HKY_contigs_hg19.bigBed (series supplementary file)
file encode accession: ENCFF000HKY
status: archived
file format: bigBed
file type: bigBed bedRnaElements
file size: 18500818
md5sum: 45213510ae143c50a220c860c9fe5730
output category: annotation
output type: contigs
assembly: hg19
biological replicates: 
technical replicates: 

***************
file name: ENCFF000HLG_gene_quantifications_hg19.gtf.gz (series supplementary file)
file encode accession: ENCFF000HLG
status: archived
file format: gtf
file type: gtf
file size: 5755861
md5sum: 9ff02541066ec968e5e4f38a325fc6e8
content md5sum: 2b3ab981895950463e5638fddf7a4292
output category: quantification
output type: gene quantifications
assembly: hg19
biological replicates: 
technical replicates: 

***************
file name: ENCFF000HLY_transcript_quantifications_hg19.gtf.gz (series supplementary file)
file encode accession: ENCFF000HLY
status: archived
file format: gtf
file type: gtf
file size: 7451571
md5sum: 2223d6122fc262407e81a9e8566e04b9
content md5sum: afb1cc2c4034e170d544a04b4cdd67af
output category: quantification
output type: transcript quantifications
assembly: hg19
biological replicates: 
technical replicates: 

***************
file name: ENCFF000HKZ_exon_quantifications_hg19.gtf.gz (series supplementary file)
file encode accession: ENCFF000HKZ
status: archived
file format: gtf
file type: gtf
file size: 10014127
md5sum: 4d8f1c1268a31af54b7087deaf04fadd
content md5sum: d8adfb9e1944dae2787a01050d447ec4
output category: quantification
output type: exon quantifications
assembly: hg19
biological replicates: 
technical replicates: 

***************
file name: ENCFF000HLM_splice_junctions_hg19.bigBed (series supplementary file)
file encode accession: ENCFF000HLM
status: archived
file format: bigBed
file type: bigBed bedRnaElements
file size: 10178050
md5sum: ab01b7bfbe85e148ce252b4547bbd563
output category: annotation
output type: splice junctions
assembly: hg19
biological replicates: 
technical replicates: 

***************
file name: ENCFF000HLI_gene_quantifications_hg19.gtf.gz (series supplementary file)
file encode accession: ENCFF000HLI
status: archived
file format: gtf
file type: gtf
file size: 6840864
md5sum: 60daa7f6cf2f5faf8cb22f53a87bea90
content md5sum: e5186a03d4eab9d32361be8bcb7677eb
output category: quantification
output type: gene quantifications
assembly: hg19
biological replicates: 
technical replicates: 

***************
file name: ENCFF000HLZ_transcript_quantifications_hg19.gtf.gz (series supplementary file)
file encode accession: ENCFF000HLZ
status: archived
file format: gtf
file type: gtf
file size: 30442669
md5sum: 26b761969212708830aa8e6ce203aa5a
content md5sum: 68117a56e8955407630c386b5a89dcda
output category: quantification
output type: transcript quantifications
assembly: hg19
biological replicates: 
technical replicates: 

***************
file name: ENCFF000HLK_gene_quantifications_hg19.gtf.gz (series supplementary file)
file encode accession: ENCFF000HLK
status: archived
file format: gtf
file type: gtf
file size: 2063159
md5sum: 32f45a84e431a5a984cb1d52bab5fb2c
content md5sum: 7c4c5ac474293ad34d9788fbbf2a15fb
output category: quantification
output type: gene quantifications
assembly: hg19
biological replicates: 
technical replicates: 

***************
file name: ENCFF000HLB_exon_quantifications_hg19.gtf.gz (series supplementary file)
file encode accession: ENCFF000HLB
status: archived
file format: gtf
file type: gtf
file size: 18554654
md5sum: 9758deef97da65466f7d6c73663d840d
content md5sum: 526e97b26a46e57fd37e8a9a39555030
output category: quantification
output type: exon quantifications
assembly: hg19
biological replicates: 
technical replicates: 

***************
file name: ENCFF044NVY_contigs_hg19.bed.gz (series supplementary file)
file encode accession: ENCFF044NVY
status: archived
file format: bed
file type: bed bedRnaElements
file size: 12409747
md5sum: f31cc4661baeeb52b09faec75a0a52e5
content md5sum: b4ba66d3d1604cd176e7eb5b252f9cd3
output category: annotation
output type: contigs
assembly: hg19
biological replicates: 
technical replicates: 
derived from: ENCFF000HKY.bigBed

***************
file name: ENCFF187LMU_splice_junctions_hg19.bed.gz (series supplementary file)
file encode accession: ENCFF187LMU
status: archived
file format: bed
file type: bed bedRnaElements
file size: 9497276
md5sum: 4f4c089a65770dd7012f8c0b9d9ded0f
content md5sum: a7a81ed1e67a7d723560e99a0b45b7b9
output category: annotation
output type: splice junctions
assembly: hg19
biological replicates: 
technical replicates: 
derived from: ENCFF000HLM.bigBed
